<?php
$con=mysqli_connect('localhost','root','','mailstore');
mysqli_select_db($con,'mailstore');
?>
